package runnableEjemplo;

public class Contador implements Runnable{
	public Contador(){
	
	}

	public void calcularPares(){

		for(int i = 0; i < 100; i++){
			if(i % 2 == 0){
				System.out.println(i);
			}
		}
	}

	public void run(){
		calcularPares();
	}
}