package runnableEjemplo;

public class Runnablejemplo {

	public static void main(String [] args) {
		
		new Thread( new Runnable(){
			public void calcularPares(){

				for(int i = 0; i < 100; i++){
					if(i % 2 == 0){
						System.out.println(i);
					}
				}
			}

			public void run(){
				calcularPares();
			}
		}).start();

	}
}