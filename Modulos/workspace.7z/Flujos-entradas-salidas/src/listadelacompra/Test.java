package listadelacompra;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Test {
	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int op = 0;
		
		do{
		try {
			
			System.out.println("Bienvenido a su lista de la compra, �que desea?\n"
					+ "1 - Escribir en la lista\n"
					+ "2 - Ver la lista\n"
					+ "3 - Rehacer la lista\n"
					+ "0 - Salir");
			
			op = Integer.parseInt(sc.nextLine());
			
			switch(op){
			case 1: 
				DataOutputStream dos = new DataOutputStream (new FileOutputStream("Lista de la compra.txt"));
				String producto;
				int cantidad;
				
				try {
					do{
						System.out.println("�Qu� producto quiere a�adir?");
						producto = sc.nextLine();
		
						System.out.println("�Cu�ntos?");
						cantidad = Integer.parseInt(sc.nextLine());
				
						dos.writeUTF(producto +", "+cantidad+" unidades");
						
					
						do{
							System.out.println("�Alguno mas?\n"
									+ "1 - Si\n"
									+ "2 - No");
							
							op = Integer.parseInt(sc.nextLine());
						}while(op != 1 && op != 2);
						
					}while(op == 1);
				
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					try {
						dos.close();
						System.out.println("Se ha actualizado la lista de la compra.\n");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				
				break;
			case 2:
				DataInputStream dis = new DataInputStream(new FileInputStream("Lista de la compra.txt"));
				String lineaTxt = "-";
				
				System.out.println("**LISTA DE LA COMPRA**");
				
				try {
					while(true){
						lineaTxt = dis.readUTF();
						System.out.println(lineaTxt);
					}
				} catch (EOFException eof) {
					System.out.println("**********************\n");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;
			case 3:
				break;
			default:
				break;
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}while(op != 0);
	}

}
