package testde100numerosLeer;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Testde100numeros {
	public static final int EOF = -1;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1) Abrir el flujo
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream("numeros.dat"); // .dat es una extensi�n ambigua, tan solo por asignar una
		
		//2)Mientras haya datos que leer, leerlos
			int c = fileInputStream.read();
			
			while (c != EOF){
				System.out.println(c);
				c = fileInputStream.read();
			}
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(fileInputStream != null){
				try {
					fileInputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		

		//3) Cerrar el flujo
		
	}

}
