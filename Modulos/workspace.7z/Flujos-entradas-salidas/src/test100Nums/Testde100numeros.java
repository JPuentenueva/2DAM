package test100Nums;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Testde100numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1) Abrir el flujo
		FileOutputStream fileOutputStream = null;
		try {
			fileOutputStream = new FileOutputStream("numeros.dat"); // .dat es una extensi�n ambigua, tan solo por asignar una
		
		//2)Mientras haya datos que escribir, escribirlos
		for(int i = 0; i < 100; i++){
			fileOutputStream.write(i);
		}
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(fileOutputStream != null){
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		

		//3) Cerrar el flujo
		
	}

}
