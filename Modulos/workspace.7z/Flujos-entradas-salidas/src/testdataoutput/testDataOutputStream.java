package testdataoutput;

public class testDataOutputStream {
	
}
