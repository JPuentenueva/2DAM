package copiarFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {

	public static final int EOF = -1;
	
	public static void main(String[] args) {
		File pdf = new File("AD_Transparencias_Tema1.pdf");
		File pdfCopy = new File("copia_AD_Transparencias_Tema1.pdf");
		int contenido;
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(pdf);
			fos = new FileOutputStream(pdfCopy);
			do{
				contenido = fis.read();
				if(contenido != EOF){
					fos.write(contenido);
				}
			}while(contenido == EOF);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (fis != null){
					fis.close();
				}
				if (fos != null){
					fos.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
