package copiarFile;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainBufferedAlternativo {

	public static final int TAM = 50 * 1024;
	public static final int EOF = -1;
	
	public static void main(String[] args) {
		File pdf = new File("AD_Transparencias_Tema1.pdf");
		File pdfCopy = new File("copia_AD_Transparencias_Tema1.pdf");
		int contenido;
		byte[] buffer = new byte[TAM];
		
		try (BufferedInputStream bis = new InputStream(pdf);
				BufferedOutputStream bos = new OutputStream(pdfCopy);){
			do{
				contenido = fis.read();
				
				if(contenido != EOF){
					fos.write(contenido);
				}
			}while(contenido == EOF);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
