import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {

	private static int EOF = -1;
	private static int TAM = 512*1024;
	private static int NUM_VECES = 1;
	
	public static void main(String[] args) {

		String nombreOrigen = "Evaluacion inicial EIE.txt";
		String nombreDestino = "";
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(nombreOrigen);
			BufferedInputStream bis = new BufferedInputStream(fis);
			
			byte [] buff = new byte[TAM];
			
			while ((bis.read(buff, 0, TAM)) != EOF) {
				String[] nombreO = nombreOrigen.split(".");
				nombreDestino = nombreO[0] + NUM_VECES + "." + nombreO[1];
				
				fos = new FileOutputStream(nombreDestino);
				BufferedOutputStream bos = new BufferedOutputStream(fos);
				
				bos.write(buff, 0, TAM);

				NUM_VECES++;
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
