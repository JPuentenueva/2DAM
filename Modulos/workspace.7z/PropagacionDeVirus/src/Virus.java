
public class Virus {
	private int posicion;
	private String patron;
	
	public Virus(){
		this.posicion = 0;
		this.patron = "";
	}
	
	public int getPosicion() {
		return posicion;
	}

	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}

	public String getPatron() {
		return patron;
	}

	public void setPatron(String patron) {
		this.patron = patron;
	}



	public void avanzarA(){
		this.posicion = this.posicion + 1;
		this.patron = this.patron + "A";
	}
	
	public void avanzarB() {
		this.posicion = this.posicion + 2;
		this.patron = this.patron + "B";
	}
}
