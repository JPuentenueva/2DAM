import java.util.ArrayList;

public class Algoritmo {
	
	ArrayList<Virus> viruses;
	int tamanyoLimite;
	
	public Algoritmo(int tamanyo) {
		this.tamanyoLimite = tamanyo;
	}
	
	public void calcularPatronVirus() {
		Virus v = new Virus();
		
		while(v.getPosicion() < this.tamanyoLimite){
			if(!existePatron(v.getPatron()) && !(v.getPosicion() == this.tamanyoLimite)){
			
				if(this.tamanyoLimite - v.getPosicion() > 1){
					v.avanzarA();
				}else{
					v.avanzarA();
				}
				
			}
			
			
		}
		
		this.viruses.add(v);
	}
	
	public boolean existePatron(String patron) {
		return false;
		
	}

}
